# Peblo TV Mini — Full Stack Take-Home

A pragmatic FastAPI + PostgreSQL + React/TypeScript implementation of the CMS → publish → viewer catalogue flow.

## Run

1. Install Docker Desktop.
2. Copy `.env.example` to `.env` and replace secrets for non-demo use.
3. Run `docker-compose up --build`.
4. CMS: http://localhost:5173 — demo `admin/admin` or `editor/editor`.
5. Viewer: http://localhost:5174.
6. API docs: http://localhost:8000/docs.

The API seeds eight shows and sample episodes on first boot. The supplied `seed_shows.json` contains representative 95-row-style seed data and `reference.json` records the validation conventions used by this implementation. Sample good/bad artwork is in `assets/`.

## Architecture

- **Backend:** FastAPI, SQLAlchemy, PostgreSQL. Resources are shows → seasons → episodes, plus artwork and publish runs.
- **Storage:** `Storage_ROOT` is a filesystem abstraction boundary in the demo. Artwork and the published catalogue live under `/storage`; production can replace the filesystem adapter with Cloudflare R2 without changing API/domain code.
- **CMS:** React + TypeScript + TanStack Query. Editor/admin roles are checked by the API, not trusted from the UI.
- **Viewer:** React reads only `/catalog` or `/catalog/search`; it never uses admin endpoints.

## Publishing atomicity

A publish first validates the complete dataset, builds a deterministic JSON document in memory, writes it to a versioned temporary file, then swaps it into `catalogue.json` with an atomic filesystem replace. A reader therefore sees either the previous complete catalogue or the new complete catalogue, never a partially written JSON file. If the process dies before the replace, the old catalogue remains live and the temporary file can be cleaned up later. The publish run is recorded as started/success/blocked.

## Grouping and trailers

Season 0 is omitted from normal catalogue seasons. Episodes with the same `content_group` are collapsed into one catalogue episode and their available languages are collected into `languages`.

## Search trade-off

Search runs against the pre-published catalogue and supports show title, episode title, category, section, and language. This is intentionally simple and fast for a small catalogue. Once the catalogue becomes large enough that loading/scanning it per request creates material latency or memory pressure (roughly tens of thousands of episodes), I would move search to PostgreSQL full-text/trigram indexes or a dedicated search service, while keeping the same API contract.

## Why publish a file?

The viewer is a read-heavy surface. A prebuilt immutable-ish catalogue removes repeated joins/grouping from viewer requests, makes CDN caching straightforward, and decouples viewer traffic from CMS database load. The trade-off is freshness: changes are not visible until publish, and a bad publish can affect all readers, so validation and atomic replacement matter.

## Storage migration to R2

Only the storage adapter needs to change: replace filesystem `write_bytes/read_text` operations with an R2 client that uploads to a temporary object key and promotes/renames the catalogue key (or uses versioned keys plus a small pointer). The domain model stores object paths/keys, not local paths.

## What I left out / why

This take-home prioritizes correctness and operability over feature count. The CMS is intentionally compact: the core list/search, role-aware login, validation report, and publish workflow are implemented. A production-ready submission would expand the editor into full show/season/episode CRUD screens, three-slot upload UX with previews, pagination/filter controls, viewer show-detail routing, real identity-provider authentication, stronger migration coverage, and object-storage URLs. These are straightforward extensions of the API contracts already present. I did not add optional rollback/dry-run/audit-log stretch features because they would reduce time available for the core atomic publish path.

## AI use and judgment

AI assistance was used to accelerate boilerplate and review edge cases. I retained the core design decisions manually: API role enforcement, server-side artwork validation, content-group grouping, Season 0 handling, deterministic catalogue generation, and atomic replacement. Generated suggestions were rejected where they would have trusted client-side validation or overwritten the live catalogue directly.

## Tests

`backend/tests/test_validation.py` covers valid artwork, wrong aspect ratio, and undersized images. The highest-risk remaining tests should cover duplicate `(content_group, language)`, publish blocking, grouping, Season 0 exclusion, atomic publish failure, and role permissions.

## CI / production deploy

GitHub Actions runs Python tests and builds all three images. A real deploy would authenticate to a container registry, push immutable SHA-tagged images, run database migrations as a one-shot job, then roll the API/CMS/viewer services. Secrets should live in GitHub Environments or the cloud secret manager, never in the repository or image layers.

## Operability

`GET /health` checks API/database reachability. The first alert I would add is **publish failure/block rate**, because a broken catalogue publish directly prevents content from reaching the viewer. I would also monitor API 5xx rate and storage upload failures.

## Screen recording

The challenge asks for a screen recording. This repository cannot attach a genuine user-recorded video. Before submission, record a 2–4 minute walkthrough showing: `docker-compose up`, CMS login, validation report, publish, viewer browse/search, and the API health/docs endpoint. Upload the recording separately if the form allows it, or include its shared link in the README.
