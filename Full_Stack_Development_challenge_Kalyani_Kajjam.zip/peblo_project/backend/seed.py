from app.main import *
Base.metadata.create_all(engine)
s=SessionLocal()
if not s.scalar(select(Show)):
    sections=['Stories','Learning','Adventure','News']; cats=['Animation','Learning','Comedy','Science']
    for i in range(8):
        sh=Show(title=f'Peblo Show {i+1}',synopsis=f'Original Indian animated adventures for curious kids.',section=sections[i%4],category=cats[i%4],published=True,featured=i<2); s.add(sh); s.flush()
        for sn in [0,1,2]:
            se=Season(show_id=sh.id,number=sn,title='Trailer' if sn==0 else f'Season {sn}'); s.add(se); s.flush()
            for e in range(4 if sn==0 else 6):
                for lang in (['English','Hindi'] if e%4==0 and sn>0 else ['English']):
                    ep=Episode(season_id=se.id,title=f'Episode {e+1}',synopsis='A short, cheerful episode.',duration_seconds=420,language=lang,content_group=f'show{i+1}-s{sn}-e{e+1}',published=True if sn>0 else False,poster='seed/poster.jpg',banner='seed/banner.jpg',thumbnail='seed/thumb.jpg'); s.add(ep)
s.commit(); print('seeded')
