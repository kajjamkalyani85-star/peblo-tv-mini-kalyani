import os, json, uuid, hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
import jwt
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Query
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field
from PIL import Image
from sqlalchemy import create_engine, String, Integer, Boolean, Text, DateTime, ForeignKey, UniqueConstraint, select, or_, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, Session, sessionmaker

DATABASE_URL=os.getenv('DATABASE_URL','postgresql+psycopg://peblo:peblo@db:5432/peblo')
STORAGE_ROOT=Path(os.getenv('STORAGE_ROOT','/storage')); STORAGE_ROOT.mkdir(parents=True,exist_ok=True)
SECRET=os.getenv('JWT_SECRET','dev-secret-change-me')
engine=create_engine(DATABASE_URL,pool_pre_ping=True)
SessionLocal=sessionmaker(bind=engine,autoflush=False,expire_on_commit=False)

class Base(DeclarativeBase): pass
class Show(Base):
    __tablename__='shows'; id:Mapped[int]=mapped_column(primary_key=True); title:Mapped[str]=mapped_column(String(200)); synopsis:Mapped[str]=mapped_column(Text,default=''); section:Mapped[Optional[str]]=mapped_column(String(80),nullable=True); category:Mapped[Optional[str]]=mapped_column(String(80),nullable=True); published:Mapped[bool]=mapped_column(Boolean,default=False); featured:Mapped[bool]=mapped_column(Boolean,default=False)
    seasons:Mapped[list['Season']]=relationship(cascade='all, delete-orphan')
class Season(Base):
    __tablename__='seasons'; id:Mapped[int]=mapped_column(primary_key=True); show_id:Mapped[int]=mapped_column(ForeignKey('shows.id',ondelete='CASCADE')); number:Mapped[int]=mapped_column(Integer); title:Mapped[str]=mapped_column(String(200),default=''); episodes:Mapped[list['Episode']]=relationship(cascade='all, delete-orphan')
    __table_args__=(UniqueConstraint('show_id','number'),)
class Episode(Base):
    __tablename__='episodes'; id:Mapped[int]=mapped_column(primary_key=True); season_id:Mapped[int]=mapped_column(ForeignKey('seasons.id',ondelete='CASCADE')); title:Mapped[str]=mapped_column(String(200)); synopsis:Mapped[str]=mapped_column(Text,default=''); duration_seconds:Mapped[Optional[int]]=mapped_column(Integer,nullable=True); language:Mapped[str]=mapped_column(String(20)); content_group:Mapped[str]=mapped_column(String(120)); published:Mapped[bool]=mapped_column(Boolean,default=False); poster:Mapped[Optional[str]]=mapped_column(String(500),nullable=True); banner:Mapped[Optional[str]]=mapped_column(String(500),nullable=True); thumbnail:Mapped[Optional[str]]=mapped_column(String(500),nullable=True)
    __table_args__=(UniqueConstraint('content_group','language'),)
class Artwork(Base):
    __tablename__='artwork'; id:Mapped[int]=mapped_column(primary_key=True); episode_id:Mapped[int]=mapped_column(ForeignKey('episodes.id',ondelete='CASCADE')); kind:Mapped[str]=mapped_column(String(20)); path:Mapped[str]=mapped_column(String(500)); width:Mapped[int]=mapped_column(Integer); height:Mapped[int]=mapped_column(Integer); size_bytes:Mapped[int]=mapped_column(Integer)
    __table_args__=(UniqueConstraint('episode_id','kind'),)
class PublishRun(Base):
    __tablename__='publish_runs'; id:Mapped[int]=mapped_column(primary_key=True); started_at:Mapped[datetime]=mapped_column(DateTime(timezone=True)); finished_at:Mapped[Optional[datetime]]=mapped_column(DateTime(timezone=True),nullable=True); actor:Mapped[str]=mapped_column(String(120)); shows_count:Mapped[int]=mapped_column(Integer,default=0); episodes_count:Mapped[int]=mapped_column(Integer,default=0); outcome:Mapped[str]=mapped_column(String(30)); message:Mapped[str]=mapped_column(Text,default='')

app=FastAPI(title='Peblo TV Mini API',version='1.0.0'); bearer=HTTPBearer(auto_error=False)

def db():
    s=SessionLocal()
    try: yield s
    finally: s.close()
def user(creds:HTTPAuthorizationCredentials=Depends(bearer)):
    if not creds: raise HTTPException(401,'Authentication required')
    try: return jwt.decode(creds.credentials,SECRET,algorithms=['HS256'])
    except Exception: raise HTTPException(401,'Invalid or expired token')
def role(required):
    def dep(u=Depends(user)):
        if u.get('role') not in (['admin'] if required=='admin' else ['editor','admin']): raise HTTPException(403,'Permission denied for this action')
        return u
    return dep

class ShowIn(BaseModel): title:str; synopsis:str=''; section:Optional[str]=None; category:Optional[str]=None; published:bool=False; featured:bool=False
class SeasonIn(BaseModel): show_id:int; number:int=Field(ge=0); title:str=''
class EpisodeIn(BaseModel): season_id:int; title:str; synopsis:str=''; duration_seconds:Optional[int]=Field(default=None,gt=0); language:str; content_group:str; published:bool=False

@app.get('/health')
def health(s:Session=Depends(db)): s.execute(select(func.count(Show.id))); return {'status':'ok','database':'ok'}
@app.post('/auth/login')
def login(username:str='admin',password:str='admin'):
    # Challenge demo users. In production, credentials live in an identity provider.
    if (username,password) not in {('admin','admin'),('editor','editor')}: raise HTTPException(401,'Invalid credentials')
    return {'access_token':jwt.encode({'sub':username,'role':username,'exp':datetime.now(timezone.utc).timestamp()+86400},SECRET,algorithm='HS256'),'role':username}

def show_json(x): return {'id':x.id,'title':x.title,'synopsis':x.synopsis,'section':x.section,'category':x.category,'published':x.published,'featured':x.featured}
@app.get('/admin/shows')
def list_shows(q:str='',section:str='',status:str='',language:str='',page:int=1,page_size:int=12,s:Session=Depends(db),u=Depends(role('editor'))):
    stmt=select(Show).order_by(Show.title)
    if q: stmt=stmt.where(Show.title.ilike(f'%{q}%'))
    if section: stmt=stmt.where(Show.section==section)
    if status in ('published','draft'): stmt=stmt.where(Show.published==(status=='published'))
    rows=s.scalars(stmt).all(); out=[]
    for x in rows:
        if language:
            langs={e.language for se in x.seasons for e in se.episodes}
            if language not in langs: continue
        out.append(show_json(x))
    total=len(out); return {'items':out[(page-1)*page_size:page*page_size],'total':total,'page':page,'page_size':page_size}
@app.post('/admin/shows')
def create_show(x:ShowIn,s:Session=Depends(db),u=Depends(role('editor'))):
    obj=Show(**x.model_dump()); s.add(obj); s.commit(); s.refresh(obj); return show_json(obj)
@app.put('/admin/shows/{id}')
def update_show(id:int,x:ShowIn,s:Session=Depends(db),u=Depends(role('editor'))):
    obj=s.get(Show,id) or (_ for _ in ()).throw(HTTPException(404,'Show not found'))
    for k,v in x.model_dump().items(): setattr(obj,k,v)
    s.commit(); return show_json(obj)
@app.delete('/admin/shows/{id}')
def delete_show(id:int,s:Session=Depends(db),u=Depends(role('editor'))):
    obj=s.get(Show,id) or (_ for _ in ()).throw(HTTPException(404,'Show not found')); s.delete(obj); s.commit(); return {'ok':True}
@app.post('/admin/seasons')
def create_season(x:SeasonIn,s:Session=Depends(db),u=Depends(role('editor'))):
    if not s.get(Show,x.show_id): raise HTTPException(404,'Show not found')
    obj=Season(**x.model_dump()); s.add(obj); s.commit(); s.refresh(obj); return {'id':obj.id,'show_id':obj.show_id,'number':obj.number,'title':obj.title}
@app.post('/admin/episodes')
def create_episode(x:EpisodeIn,s:Session=Depends(db),u=Depends(role('editor'))):
    if not s.get(Season,x.season_id): raise HTTPException(404,'Season not found')
    if s.scalar(select(Episode).where(Episode.content_group==x.content_group,Episode.language==x.language)): raise HTTPException(409,'This content group already has that language')
    obj=Episode(**x.model_dump()); s.add(obj); s.commit(); s.refresh(obj); return {'id':obj.id}
@app.put('/admin/episodes/{id}')
def update_episode(id:int,x:EpisodeIn,s:Session=Depends(db),u=Depends(role('editor'))):
    obj=s.get(Episode,id) or (_ for _ in ()).throw(HTTPException(404,'Episode not found'))
    dup=s.scalar(select(Episode).where(Episode.id!=id,Episode.content_group==x.content_group,Episode.language==x.language))
    if dup: raise HTTPException(409,'This content group already has that language')
    for k,v in x.model_dump().items(): setattr(obj,k,v)
    s.commit(); return {'id':obj.id}

SPECS={'poster':(2/3,600,900),'banner':(16/9,1280,720),'thumbnail':(16/9,640,360)}
def validate_art(kind,data):
    if kind not in SPECS: raise HTTPException(400,'Artwork type must be poster, banner, or thumbnail')
    if len(data)>200*1024: raise HTTPException(400,f'{kind.title()} is larger than 200 KB. Please export a smaller image.')
    try: im=Image.open(__import__('io').BytesIO(data)); w,h=im.size
    except Exception: raise HTTPException(400,'The uploaded file is not a valid image')
    ratio=w/h; target,minw,minh=SPECS[kind]
    if abs(ratio-target)>0.03: raise HTTPException(400,f'{kind.title()} must use a {"2:3" if kind=="poster" else "16:9"} aspect ratio. Your image is {w}×{h}.')
    if w<minw or h<minh: raise HTTPException(400,f'{kind.title()} must be at least {minw}×{minh}. Your image is {w}×{h}.')
    return w,h
@app.post('/admin/episodes/{id}/artwork/{kind}')
def upload_art(id:int,kind:str,file:UploadFile=File(...),s:Session=Depends(db),u=Depends(role('editor'))):
    ep=s.get(Episode,id) or (_ for _ in ()).throw(HTTPException(404,'Episode not found')); data=file.file.read(); w,h=validate_art(kind,data)
    ext=Path(file.filename or '').suffix.lower() or '.jpg'; name=f'{uuid.uuid4().hex}{ext}'; rel=f'uploads/{name}'; dest=STORAGE_ROOT/rel; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(data)
    old=s.scalar(select(Artwork).where(Artwork.episode_id==id,Artwork.kind==kind))
    if old: old.path=rel; old.width=w; old.height=h; old.size_bytes=len(data)
    else: s.add(Artwork(episode_id=id,kind=kind,path=rel,width=w,height=h,size_bytes=len(data)))
    setattr(ep,kind,rel); s.commit(); return {'kind':kind,'path':rel,'width':w,'height':h,'size_bytes':len(data)}

def validation(s):
    blockers=[]
    for show in s.scalars(select(Show)).all():
        if show.published and not show.section: blockers.append({'type':'show','id':show.id,'title':show.title,'message':'Choose a section before publishing this show.'})
        for season in show.seasons:
            for ep in season.episodes:
                if ep.published:
                    missing=[]
                    if not ep.duration_seconds: missing.append('duration')
                    if not (ep.poster or ep.banner or ep.thumbnail): missing.append('artwork')
                    if missing: blockers.append({'type':'episode','id':ep.id,'title':ep.title,'message':'Add '+ ' and '.join(missing)+ ' before publishing.'})
    return blockers
@app.get('/admin/validation-report')
def report(s:Session=Depends(db),u=Depends(role('editor'))):
    b=validation(s); return {'blocked':len(b),'issues':b}

def build_catalog(s):
    sections={}; count=0
    for show in s.scalars(select(Show).where(Show.published).order_by(Show.section,Show.title)).all():
        grouped={}
        for season in sorted(show.seasons,key=lambda z:z.number):
            if season.number==0: continue
            for ep in sorted(season.episodes,key=lambda z:z.id):
                if not ep.published: continue
                key=ep.content_group; item=grouped.setdefault(key,{'id':ep.id,'title':ep.title,'synopsis':ep.synopsis,'season':season.number,'duration_seconds':ep.duration_seconds,'languages':[],'artwork':{'poster':ep.poster,'banner':ep.banner,'thumbnail':ep.thumbnail}})
                if ep.language not in item['languages']: item['languages'].append(ep.language)
                count+=1
        entry={'id':show.id,'title':show.title,'synopsis':show.synopsis,'category':show.category,'featured':show.featured,'seasons':[]}
        for num in sorted({x['season'] for x in grouped.values()}): entry['seasons'].append({'number':num,'episodes':[x for x in grouped.values() if x['season']==num]})
        sections.setdefault(show.section,[]).append(entry)
    return {'version':datetime.now(timezone.utc).isoformat(),'sections':{k:sorted(v,key=lambda z:z['title']) for k,v in sorted(sections.items())},'counts':{'shows':sum(map(len,sections.values())),'episodes':count}}
@app.post('/admin/catalog/publish')
def publish(s:Session=Depends(db),u=Depends(role('admin'))):
    blockers=validation(s); run=PublishRun(started_at=datetime.now(timezone.utc),actor=u.get('sub','admin'),outcome='started'); s.add(run); s.commit()
    if blockers:
        run.outcome='blocked'; run.message=json.dumps(blockers); run.finished_at=datetime.now(timezone.utc); s.commit(); raise HTTPException(409,'Publish blocked. Fix the validation report first.')
    catalog=build_catalog(s); version=hashlib.sha256(json.dumps(catalog,sort_keys=True).encode()).hexdigest()[:16]; tmp=STORAGE_ROOT/f'catalogue.{version}.tmp'; live=STORAGE_ROOT/'catalogue.json'; tmp.write_text(json.dumps(catalog,indent=2)); os.replace(tmp,live)
    run.outcome='success'; run.shows_count=catalog['counts']['shows']; run.episodes_count=catalog['counts']['episodes']; run.finished_at=datetime.now(timezone.utc); s.commit(); return {'run_id':run.id,'version':version,'counts':catalog['counts']}
@app.get('/admin/publish-runs')
def runs(s:Session=Depends(db),u=Depends(role('editor'))): return [{'id':r.id,'started_at':r.started_at,'finished_at':r.finished_at,'actor':r.actor,'outcome':r.outcome,'shows':r.shows_count,'episodes':r.episodes_count} for r in s.scalars(select(PublishRun).order_by(PublishRun.id.desc()).limit(20)).all()]

def catalogue():
    p=STORAGE_ROOT/'catalogue.json'
    return json.loads(p.read_text()) if p.exists() else {'version':None,'sections':{},'counts':{'shows':0,'episodes':0}}
@app.get('/catalog')
def get_catalog(): return catalogue()
@app.get('/catalog/search')
def search(q:str='',category:str='',language:str='',section:str=''):
    c=catalogue(); out=[]
    for sec,shows in c['sections'].items():
        if section and sec!=section: continue
        for show in shows:
            text=(show['title']+' '+show.get('category','')+' '+show.get('synopsis','')).lower(); hit=(not q or q.lower() in text)
            matched_eps=[]
            for season in show['seasons']:
                for ep in season['episodes']:
                    et=(ep['title']+' '+ep.get('synopsis','')).lower(); langs=ep['languages'];
                    if (not q or q.lower() in et or q.lower() in show['title'].lower() or q.lower() in (show.get('category') or '').lower()) and (not language or language in langs): matched_eps.append(ep)
            if hit and (not language or any(language in e['languages'] for se in show['seasons'] for e in se['episodes'])) and (not q or matched_eps or q.lower() in show['title'].lower() or q.lower() in (show.get('category') or '').lower()): out.append(show)
    if category: out=[x for x in out if x.get('category')==category]
    return {'items':out}

@app.exception_handler(Exception)
def errors(request,exc):
    if isinstance(exc,HTTPException): raise exc
    return JSONResponse(status_code=500,content={'detail':'Unexpected server error'})
