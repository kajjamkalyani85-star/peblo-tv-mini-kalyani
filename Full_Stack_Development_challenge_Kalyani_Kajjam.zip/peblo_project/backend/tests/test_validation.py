import io
from PIL import Image
import pytest

def make(w,h,quality=80):
    b=io.BytesIO(); Image.new('RGB',(w,h),'white').save(b,format='JPEG',quality=quality); return b.getvalue()
def check(data,kind):
    if len(data)>200*1024: raise ValueError('size')
    w,h=Image.open(io.BytesIO(data)).size
    target={'poster':2/3,'banner':16/9,'thumbnail':16/9}[kind]
    if abs(w/h-target)>0.03: raise ValueError('ratio')
    mins={'poster':(600,900),'banner':(1280,720),'thumbnail':(640,360)}[kind]
    if w<mins[0] or h<mins[1]: raise ValueError('dimensions')
def test_good_art(): check(make(600,900),'poster'); check(make(1280,720),'banner'); check(make(640,360),'thumbnail')
def test_wrong_ratio():
    with pytest.raises(ValueError): check(make(800,800),'poster')
def test_too_small():
    with pytest.raises(ValueError): check(make(320,180),'thumbnail')
def test_too_large():
    with pytest.raises(ValueError): check(make(3000,4500,quality=100),'poster')
