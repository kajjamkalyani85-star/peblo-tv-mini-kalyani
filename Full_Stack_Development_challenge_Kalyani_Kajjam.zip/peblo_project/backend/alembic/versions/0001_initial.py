"""initial schema"""
from alembic import op
import sqlalchemy as sa
revision='0001'; down_revision=None

def upgrade():
    # The app creates tables on first boot for the take-home demo; this migration is supplied for production evolution.
    pass
def downgrade(): pass
